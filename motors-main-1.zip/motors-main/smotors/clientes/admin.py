from django.contrib import admin
from .models import Clientes, Registrar
# Register your models here.
admin.site.register(Clientes)
admin.site.register(Registrar)


