# motors
proyecto clase programación


TENER EN CUENTA LO SIGUIENTE:

*Lo ubicado en carpeta MAIN Y RAMA CAROLINA tienen el proceso de trabajo llevado en clase hasta el bootstrap.
*Sí se harán actualizaciones , pero sólo sobre la rama carolina por fines de práctica y no se volverá a sincronizar con rama MAIN.

*Para trabajar sobre este proyecto se debe crear una RAMA , pero informar sobre esto para dar acceso al request si se genera. 

*La siguiente imagen explica lo que contiene la carpeta MOTORS. //No se le puede cambiar el nombre a las carpetas, a menos que se explique 
en el request porque motivo , de lo contrario se rechazará. 

![carpeta_motors](https://user-images.githubusercontent.com/93058053/194732418-8f6bb1fe-761c-4fc0-aa48-a3aedcf0a928.png)


*Este proyecto tiene un paso a paso en el siguiente archivo: 
[proceso_entornos.txt](https://github.com/karilunius/motors/files/9740535/proceso_entornos.txt)

*Este proyecto quedó según la imagen abajo.

![Captura-estado de trabajo](https://user-images.githubusercontent.com/93058053/194732530-192bba9c-4df9-412a-99c7-cee0c59c3a13.JPG)


*ESTA CARPETA NO CONTIENE EL LADO FRONTEND - Para esto remitirse a la carpeta : //pendiente


*video sobre formas de instalar y trabajar con bootstrap
https://www.youtube.com/watch?v=rIEoF6B_GNY
